/* DO 	NOT EDIT THIS FILE - it is machine generated */
#include <jni.h>
/* Header for class com_forensicsupport_NativeLib */

#ifndef _Included_com_forensicsupport_NativeLib
#define _Included_com_forensicsupport_NativeLib
#ifdef __cplusplus
extern "C" {
#endif
/*
 * Class:     com_forensicsupport_NativeLib
 * Method:    add
 * Signature: (II)I
 */
JNIEXPORT jint JNICALL Java_com_forensicsupport_NativeLib_add
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     com_forensicsupport_NativeLib
 * Method:    hello
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_forensicsupport_NativeLib_hello
  (JNIEnv *, jobject);

#ifdef __cplusplus
}
#endif
#endif
