package com.forensicsupport;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class WriteLog 
{
    public static void Append(String data)
	{
        SimpleDateFormat DateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        Calendar c = Calendar.getInstance();
        String currentDateTimeString = DateFormat.format(c.getTime());
		try 
		{
			File myFile = new File("/sdcard/log.txt");  
			if(!myFile.exists())
			{
			myFile.createNewFile();
			}
			FileOutputStream fOut = new FileOutputStream(myFile,true);  //true for append
			OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
			
			myOutWriter.append(currentDateTimeString + " " + data + "\r\n");  
			myOutWriter.close();  
			fOut.close();			
		} 
		catch (FileNotFoundException e1) 
		{
			e1.printStackTrace();
		}  
		catch (IOException e2) 
		{
			e2.printStackTrace();
		}  
	
	}
}

	 