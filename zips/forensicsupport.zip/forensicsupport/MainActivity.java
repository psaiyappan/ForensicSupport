package com.forensicsupport;

import java.io.File;

import android.app.Activity;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	  NativeLib nativeLib = new NativeLib();

	  Button buttonWatch, buttonExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        
        buttonWatch= (Button) findViewById(R.id.buttonWatch);
    	buttonWatch.setOnClickListener(new View.OnClickListener() 
    	{
    	    @Override
    		public void onClick(View v) {	
    	    	
    	    	//Log.d("AFSF","AFSF"+  " File Exists:"+filePath );
    	

    		String helloText = nativeLib.hello();
    		//Log.d("AFSF","AFSF"+  "Exiting .. bro" );
    	//	System.exit(0);
    	    }
    	});
    	
    	/*buttonExit.setOnClickListener(new View.OnClickListener() 
    	{
    	    @Override
    		public void onClick(View v) 
    	    {	
    	    	android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
    	    }
    	});*/
    	    
      }
    }