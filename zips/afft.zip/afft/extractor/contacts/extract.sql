.header on
select * from view_contacts as R join phone_lookup as C on C.raw_contact_id=R.name_raw_contact_id;
select * from view_contacts as R join phone_lookup as C on C.raw_contact_id=R.name_raw_contact_id;
