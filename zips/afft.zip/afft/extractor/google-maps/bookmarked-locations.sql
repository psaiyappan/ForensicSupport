.header on
select key_string, timestamp, latitude, longitude from sync_item;