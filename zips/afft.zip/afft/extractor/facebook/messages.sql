.header on
select * from messages;
