.header on
select * from calls;
